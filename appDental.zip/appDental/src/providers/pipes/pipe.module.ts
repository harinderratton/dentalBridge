import { NgModule } from '@angular/core';
import  { KeysPipe } from './pipe';;

@NgModule({
  declarations: [KeysPipe],
  exports: [KeysPipe]
})
export class KeysPipeModule { }
