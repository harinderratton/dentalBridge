import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Chat1Page } from './chat1';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(Chat1Page),
  ],
})
export class Chat1PageModule {}
