import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JobOfferDetailsPage } from './job-offer-details';

@NgModule({
  declarations: [
     
  ],
  imports: [
    IonicPageModule.forChild(JobOfferDetailsPage),
  ],
})
export class JobOfferDetailsPageModule {}
