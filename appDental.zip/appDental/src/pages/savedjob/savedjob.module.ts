import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SavedjobPage } from './savedjob';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(SavedjobPage),
  ],
})
export class SavedjobPageModule {}
