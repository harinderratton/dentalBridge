import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Register1Page } from './register1';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(Register1Page),
  ],
})
export class Register1PageModule {}
