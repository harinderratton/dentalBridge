import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditEducationPage } from './edit-education';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(EditEducationPage),
  ],
})
export class EditEducationPageModule {}
