import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChooseEduPage } from './choose-edu';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(ChooseEduPage),
  ],
})
export class ChooseEduPageModule {}
