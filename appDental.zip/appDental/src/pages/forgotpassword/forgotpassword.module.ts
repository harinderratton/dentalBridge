import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ForgotpasswordPage } from './forgotpassword';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(ForgotpasswordPage),
  ],
})
export class ForgotpasswordPageModule {}
