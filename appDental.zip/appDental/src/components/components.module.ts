import { NgModule } from '@angular/core';
import { PrivacyTermsComponent } from './privacy-terms/privacy-terms';
@NgModule({
	declarations: [PrivacyTermsComponent],
	imports: [],
	exports: [PrivacyTermsComponent]
})
export class ComponentsModule {}
