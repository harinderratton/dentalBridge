import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Home1Page } from './home1';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(Home1Page),
  ],
})
export class Home1PageModule {}
