import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AppliedInfoPage } from './applied-info';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(AppliedInfoPage),
  ],
})
export class AppliedInfoPageModule {}
