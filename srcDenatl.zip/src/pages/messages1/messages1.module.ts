import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Messages1Page } from './messages1';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(Messages1Page),
  ],
})
export class Messages1PageModule {}
