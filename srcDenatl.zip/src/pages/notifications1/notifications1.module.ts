import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Notifications1Page } from './notifications1';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(Notifications1Page),
  ],
})
export class Notifications1PageModule {}
