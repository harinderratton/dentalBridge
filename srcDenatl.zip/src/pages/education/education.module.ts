import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EducationPage } from './education';

@NgModule({
  declarations: [
 
  ],
  imports: [
    IonicPageModule.forChild(EducationPage),
  ],
})
export class EducationPageModule {}
