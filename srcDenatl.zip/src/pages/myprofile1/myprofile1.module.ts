import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Myprofile1Page } from './myprofile1';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(Myprofile1Page),
  ],
})
export class Myprofile1PageModule {}
