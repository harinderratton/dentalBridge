import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Tabs1Page } from './tabs1';

@NgModule({
  declarations: [
    
  ],
  imports: [
    IonicPageModule.forChild(Tabs1Page),
  ],
})
export class Tabs1PageModule {}
