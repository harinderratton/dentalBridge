import { NgModule } from '@angular/core';
import { YoutubePipe } from './youtube/youtube';
@NgModule({
	declarations: [],
	imports: [],
	exports: []
})
export class PipesModule {}
